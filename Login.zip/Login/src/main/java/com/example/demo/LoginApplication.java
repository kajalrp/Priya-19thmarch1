package com.example.demo;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Login;
import com.example.demo.repository.LoginRepository;
import com.example.demo.service.UserService;

@SpringBootApplication
@RestController
@RequestMapping(path="/Login")
@CrossOrigin(origins = "*")
public class LoginApplication {
	
	@Autowired
	private LoginRepository loginrepository;
	
	@Autowired
    UserService service;
 

	@PostMapping("/login")
	public String login(@RequestBody Login login) {
		
		System.out.println(login.getUser_name());

		System.out.println(login.getPassword());

		loginrepository.save(login);
		return "Hi you have successfully logged in by" + login.getUser_name();
	}
	
	 @GetMapping(path="/all")
	  public @ResponseBody Iterable<Login> getAllUsers() {
	    // This returns a JSON or XML with the users
	    return loginrepository.findAll();

	  }
	 
	 @RequestMapping(value= "/user/all", method= RequestMethod.GET)
	    public List<Login> getUsers() {
	        System.out.println("Invokeed all");
	        return service.getUsers();
	    }
	 
	 @RequestMapping(value= "/user/{id}", method= RequestMethod.GET)
	    public Login getUserById(@PathVariable int id) throws Exception {
	 
	        Optional<Login> login =  service.getUserById(id);
	        if(!login.isPresent())
	            throw new Exception("Could not find user with id- " + id);
	 
	        return login.get();
	    }
	 
	 @RequestMapping(value= "/user/add", method= RequestMethod.POST)
	    public Login createUser(@RequestBody Login newlogin) {
	        return service.addNewUser(newlogin);
	    }
	 
	 
	 @RequestMapping(value= "/user/delete/{id}", method= RequestMethod.GET)
	    public void deleteUserById(@PathVariable int id) throws Exception {
	        System.out.println("Invokeed all");

	        Optional<Login> login =  service.getUserById(id);
	        if(!login.isPresent())
	            throw new Exception("Could not find employee with id- " + id);
	 
	        service.deleteUserById(id);
	    }
	 
	 
	 
	    @RequestMapping(value= "/user/deleteall", method= RequestMethod.GET)
	    public void deleteAll() {
	        System.out.println("Invokeed all");

	        service.deleteAllUsers();
	    }
	    
	    @RequestMapping(value= "/user/update/{id}", method= RequestMethod.PUT)
	    public Login updateUser(@RequestBody Login updemp, @PathVariable int id) throws Exception {
	 
	        Optional<Login> emp =  service.getUserById(id);
	        if (!emp.isPresent())
	            throw new Exception("Could not find employee with id- " + id);
	 
	        /* IMPORTANT - To prevent the overriding of the existing value of the variables in the database, 
	         * if that variable is not coming in the @RequestBody annotation object. */    
	        if(updemp.getUser_name() == null || updemp.getUser_name().isEmpty())
	            updemp.setUser_name(emp.get().getUser_name());
	        if(updemp.getPassword() == null || updemp.getPassword().isEmpty())
	            updemp.setPassword(emp.get().getPassword());
	 	        updemp.setId(id);
	        return service.updateUser(updemp);
	    }

	 
	public static void main(String[] args) {
		SpringApplication.run(LoginApplication.class, args);
	}

}
