package com.example.demo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity


@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString

@Table(name="Topic_Names")
@DynamicInsert
@DynamicUpdate
public class Topic {
	
	@Id
	  @GeneratedValue(strategy=GenerationType.AUTO)
	  private Integer id;

	  public Topic() {
		super();
		// TODO Auto-generated constructor stub
	}
	private String topic_name;
	  private String topic_description;
	  
	  private String created_by;
	  
	    @JsonFormat(pattern="yyyy-MM-dd")
	  private String created_date;
	  
	  private String modified_by;
	  
	    @JsonFormat(pattern="yyyy-MM-dd")
	  private String modified_date;

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTopic_name() {
		return topic_name;
	}
	public void setTopic_name(String topic_name) {
		this.topic_name = topic_name;
	}
	public String getTopic_description() {
		return topic_description;
	}
	public void setTopic_description(String topic_description) {
		this.topic_description = topic_description;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getCreated_date() {
		return created_date;
	}
	public void setCreated_date(String created_date) {
		this.created_date = created_date;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public String getModified_date() {
		return modified_date;
	}
	public void setModified_date(String modified_date) {
		this.modified_date = modified_date;
	}
	@Override
	public String toString() {
		return "Topic [id=" + id + ", topic_name=" + topic_name + ", topic_description=" + topic_description
				+ ", created_by=" + created_by + ", created_date=" + created_date + ", modified_by=" + modified_by
				+ ", modified_date=" + modified_date + "]";
	}
	public Topic(Integer id, String topic_name, String topic_description, String created_by, String created_date,
			String modified_by, String modified_date) {
		super();
		this.id = id;
		this.topic_name = topic_name;
		this.topic_description = topic_description;
		this.created_by = created_by;
		this.created_date = created_date;
		this.modified_by = modified_by;
		this.modified_date = modified_date;
	}
	

	
}