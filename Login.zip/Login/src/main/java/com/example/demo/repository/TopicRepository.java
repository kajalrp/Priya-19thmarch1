package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.Topic;

public interface TopicRepository extends JpaRepository<Topic, Integer>{
	Topic findById(int id);
	List<Topic> deleteById(int id);
	@Query("Select c from Topic c where c.topic_name=?1 and c.created_by=?2")
	List<Topic> findTopicByName(String topic_name,String created_by);

}


