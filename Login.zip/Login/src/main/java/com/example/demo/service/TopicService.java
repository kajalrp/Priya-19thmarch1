package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.model.Topic;

public interface TopicService {

	public List<Topic> getTopics();
	public Topic getTopicById(int id);
	public List<Topic> getTopicByName(String topic_name,String created_by);
	public Topic addNewTopic(Topic topic);
	public Topic updateTopic(Topic topic);
	public void deleteTopicById(int id);
	public void deleteAllTopics();
}
