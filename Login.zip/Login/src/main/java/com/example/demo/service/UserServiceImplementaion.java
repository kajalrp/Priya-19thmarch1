package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Login;
import com.example.demo.repository.LoginRepository;

@Service
public class UserServiceImplementaion implements UserService{

	
	 @Autowired
	    LoginRepository loginRepository;

	@Override
	public List<Login> getUsers() {
		// TODO Auto-generated method stub
		return loginRepository.findAll();
	}

	@Override
	public Optional<Login> getUserById(int id) {
		// TODO Auto-generated method stub
		return loginRepository.findById(id);
	}

	@Override
	public Login addNewUser(Login login) {
		// TODO Auto-generated method stub
		return loginRepository.save(login);
	}

	@Override
	public Login updateUser(Login login) {
		// TODO Auto-generated method stub
		return loginRepository.save(login);
	}

	@Override
	public void deleteUserById(int id) {
		// TODO Auto-generated method stub
		loginRepository.deleteById(id);
	}

	@Override
	public void deleteAllUsers() {
		// TODO Auto-generated method stub
		loginRepository.deleteAll();
	}
	 
	 
}
