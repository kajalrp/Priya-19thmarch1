export class Topic{
  length: number;
    constructor(
        public id: String,
        public topic_name: string,
        public topic_description: string,
        public created_by: string,
        public created_date: string,
        public modified_by: string,
        public modified_date: string,


      
    ){}
    
}