import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FindUserByIDPageRoutingModule } from './find-user-by-id-routing.module';

import { FindUserByIDPage } from './find-user-by-id.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FindUserByIDPageRoutingModule
  ],
  declarations: [FindUserByIDPage]
})
export class FindUserByIDPageModule {}
