import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { FindUserByIDPage } from './find-user-by-id.page';

describe('FindUserByIDPage', () => {
  let component: FindUserByIDPage;
  let fixture: ComponentFixture<FindUserByIDPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FindUserByIDPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(FindUserByIDPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
