import { Component, OnInit } from '@angular/core';
import {Login} from '../Login';


@Component({
  selector: 'app-find-user-by-id',
  templateUrl: './find-user-by-id.page.html',
  styleUrls: ['./find-user-by-id.page.scss'],
})
export class FindUserByIDPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
