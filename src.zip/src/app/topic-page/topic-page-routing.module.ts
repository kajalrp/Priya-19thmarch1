import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from "@angular/forms"; //this to use ngModule

import { TopicPagePage } from './topic-page.page';

const routes: Routes = [
  {
    path: '',
    component: TopicPagePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes),FormsModule,ReactiveFormsModule],
  exports: [RouterModule],
})
export class TopicPagePageRoutingModule {}
