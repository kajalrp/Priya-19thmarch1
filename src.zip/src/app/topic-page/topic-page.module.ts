import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TopicPagePageRoutingModule } from './topic-page-routing.module';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';

import { TopicPagePage } from './topic-page.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,NgxDatatableModule,
    TopicPagePageRoutingModule
  ],
  declarations: [TopicPagePage]
})
export class TopicPagePageModule {}
