import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { TopicPagePage } from './topic-page.page';

describe('TopicPagePage', () => {
  let component: TopicPagePage;
  let fixture: ComponentFixture<TopicPagePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TopicPagePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(TopicPagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
